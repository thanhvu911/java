import java.util.ArrayList;

class MazeSolver {

	private Agenda agenda;

	public MazeSolver(Agenda a) {
		// Your code goes here!
		a.clear();
		agenda = a;
	}

	/**
	 * Trace back location from the goal to the start
	 * 
	 * @param list    list of location to solution path
	 * @param prev    2d array that keeps track of the previous location of the
	 *                current one
	 * @param mg      The mazeGUI to make changes to the maze colors
	 * @param currLoc Current location (start with goal)
	 * @param start   The start location of the maze
	 * @return an arrayList of solution location
	 */
	private ArrayList<MazeGridLocation> traceBack(ArrayList<MazeGridLocation> list, MazeGridLocation[][] prev,
			MazeGUI mg, MazeGridLocation currLoc, MazeGridLocation start) {
		// Base case if currLoc is the start
		if (currLoc == start) {
			return list;

			// Recursive case
		} else {
			// Get the previous location of current location(part of the solution), change
			// current location to previous
			// Recursively call traceback, when it reaches the end add location from start
			// to end
			currLoc = prev[currLoc.getRow()][currLoc.getColumn()];
			traceBack(list, prev, mg, currLoc, start);
			list.add(currLoc);
			// Mark the locations that are part of the solution path
			mg.addLocToPath(currLoc);
			return list;
		}
	}

	/**
	 * Method to solve the maze
	 * 
	 * @return an arrayList of solution (enmpty list if there are no solution)
	 */

	public ArrayList<MazeGridLocation> solveMaze(Maze m, MazeGUI mg) {
		// Your code goes here!
		agenda.clear();

		ArrayList<MazeGridLocation> temp = new ArrayList<MazeGridLocation>();
		MazeGridLocation[][] prev = new MazeGridLocation[m.getNumRows()][m.getNumColumns()];
		MazeGridLocation start = m.getStartLocation();
		MazeGridLocation goal = m.getGoalLocation();
		agenda.addLocation(start);
		// Loop till list is empty to check if there is a possible solution
		while (!(agenda.isEmpty())) {
			MazeGridLocation currLoc = agenda.removeLocation();
			m.markVisited(currLoc);
			mg.visitLoc(currLoc);

			// If current location reach goal, return an arrayList of solution

			if (currLoc.equals(goal)) {
				temp = traceBack(temp, prev, mg, currLoc, start);
				temp.add(goal);
				return temp;
			} else {
				for (MazeGridLocation next : m.getOpenNeighbors(currLoc)) {
					if (!(m.isVisited(next))) {
						prev[next.getRow()][next.getColumn()] = currLoc;
						agenda.addLocation(next);
						mg.addLocToAgenda(next);

					}
				}
			}

		}
		return temp;
	}
}