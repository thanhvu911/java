import java.util.ArrayList;

public class ObjectHashMap extends AbstractHashMap {

    private ArrayList<Entry>[] table;

    public ObjectHashMap(double maxLoad) {
        super(maxLoad);
        table = new ArrayList[capacity];
        for (int i = 0; i < capacity; i++) {
            table[i] = new ArrayList<Entry>();
        }
    }

    public ObjectHashMap() {
        super(0.7);
        table = new ArrayList[capacity];
        for (int i = 0; i < capacity; i++) {
            table[i] = new ArrayList<Entry>();
        }
    }

    @Override
    public void put(Object key, Object value) {
        if (key == null) {
            throw new IllegalArgumentException("Invalid key");
        }
        Entry curEntry = findEntry(key);
        if (curEntry != null) {
            curEntry.value = value;
        } else {
            ArrayList<Entry> bucket = table[hash(key)];
            bucket.add(new Entry(key, value));
            numKeys++;
            if (numKeys / capacity > maxLoad) {
                resize();
            }
        }
    }

    public Object get(Object key) {
        int bucketIndex = hash(key);
        ArrayList<Entry> bucket = table[bucketIndex];
        for (Entry entry : bucket) {
            if (entry.key.equals(key)) {
                return entry.value;
            }
        }
        return null;
    }

    @Override
    public Object find(Object key) {
        if (key == null) {
            throw new IllegalArgumentException("Invalid key");
        }
        Entry curEntry = findEntry(key);
        if (curEntry != null) {
            return curEntry.value;
        } else {
            return null;
        }
    }

    @Override
    protected void resize() {
        Entry[] curEntries = getEntries();
        capacity *= 2;
        numKeys = 0;
        table = new ArrayList[capacity];
        for (int i = 0; i < capacity; i++) {
            table[i] = new ArrayList<Entry>();
        }
        for (Entry e : curEntries) {
            put(e.key, e.value);
        }
    }

    @Override
    public boolean containsKey(Object key) {
        return findEntry(key) != null;
    }

    @Override
    public Entry[] getEntries() {
        Entry[] entryArray = new Entry[numKeys];
        int count = 0;
        for (ArrayList<Entry> bucket : table) {
            for (Entry e : bucket) {
                entryArray[count++] = e;
            }
        }
        return entryArray;
    }

    public Entry findEntry(Object key) {
        int h = hash(key);
        ArrayList<Entry> bucket = table[h];
        for (Entry e : bucket) {
            if (e.key.equals(key)) {
                return e;
            }
        }
        return null;
    }
}