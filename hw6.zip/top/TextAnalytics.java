import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TextAnalytics {
    private static ObjectHashMap hashMap = new ObjectHashMap(0.8);

    // This method has O(n) complexity, where n is the number of words in the file.
    // Each word is processed individually.
    private static void scanFile(String fileName) throws FileNotFoundException {
        File inputFile = new File(fileName);
        Scanner fileScanner = new Scanner(inputFile);
        boolean isEligibleForProcessing = false;

        while (fileScanner.hasNextLine()) {
            String currentLine = fileScanner.nextLine();

            if (currentLine.contains("*** START OF THIS PROJECT GUTENBERG EBOOK")) {
                isEligibleForProcessing = true;
                continue;
            } else if (currentLine.contains("*** END OF THIS PROJECT GUTENBERG EBOOK")) {
                isEligibleForProcessing = false;
                continue;
            }

            if (isEligibleForProcessing) {
                for (String extractedWord : currentLine.toLowerCase().split("\\s+")) {
                    extractedWord = extractedWord.replaceAll("[^a-z]", "");
                    if (!extractedWord.isEmpty()) {
                        int wordFrequency;
                        if (hashMap.containsKey(extractedWord)) {
                            wordFrequency = (Integer) hashMap.get(extractedWord);
                            hashMap.put(extractedWord, wordFrequency + 1);
                        } else {
                            hashMap.put(extractedWord, 1);
                        }
                    }
                }
            }
        }
        fileScanner.close();
    }

    // The insertion sort method has a worst-case time complexity of O(n^2),
    // where n is the number of entries in the array.
    // This can be significant if the number of unique words is large.
    public static void insertionSort(Entry[] arr) {
        for (int i = 1; i < arr.length; i++) {
            Entry current = arr[i];
            int j = i - 1;
            while (j >= 0 && ((Integer) arr[j].value) < ((Integer) current.value)) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = current;
        }
    }

    // This method has O(n) complexity due to the sorting step.
    private static void printTopWords() {
        Entry[] entries = hashMap.getEntries();
        insertionSort(entries);
        System.out.println("--Top 5 Most Frequent Words--");
        for (int i = 0; i < Math.min(5, entries.length); i++) {
            System.out.println((i + 1) + ".) '" + entries[i].key + "' " + entries[i].value + " uses.");
        }
    }

    public static void main(String[] args) {
        // Other parts of the main method have a complexity less than O(n).
        if (args.length != 1) {
            System.err.println("Usage: java TextAnalytics <filename>");
            System.exit(1);
        }

        try {
            scanFile(args[0]);
            printTopWords();
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + args[0]);
            System.exit(1);
        }

        // The loop for user input does not directly depend on the number of words in
        // the file.
        Scanner input = new Scanner(System.in);
        while (true) {
            System.out.print("Type a word or type 'q' to quit: ");
            String word = input.next().toLowerCase().replaceAll("[^a-z]", "");
            if (word.equals("q")) {
                break;
            }
            Integer frequency = (Integer) hashMap.get(word);
            if (frequency != null) {
                System.out.println("The word '" + word + "' occurs " + frequency + " times.");
            } else {
                System.out.println("The word '" + word + "' is not present.");
            }
        }
        input.close();
    }
}
